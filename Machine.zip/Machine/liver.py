#!/usr/bin/env python
# coding: utf-8

# # IMPORT LIBRABRIES

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import r2_score
from sklearn.feature_selection import SelectFromModel


# # IMPORT DATASET

# In[2]:


dataset=pd.read_csv('indian_liver_patient.csv')
dataset


# In[ ]:

def partition(x):
    if x == 2:
        return 0
    return 1

dataset['Dataset'] = dataset['Dataset'].map(partition)



# In[3]:


dataset.shape


# # DATA VISUALIZATION

# In[4]:


dataset.hist(figsize=(20,20), bins=10,color='orange')
plt.show()


# # REMOVING OUTLIERS

# In[5]:


dataset.describe()


# In[6]:


dataset=dataset.drop_duplicates()
print(dataset.shape)


# In[7]:


import seaborn as sns
#Aspartate_Aminotransferase's max value is very high than mean value
sns.boxplot(dataset.Aspartate_Aminotransferase) 


# In[8]:


dataset.Aspartate_Aminotransferase.sort_values(ascending=False).head()


# In[9]:


dataset = dataset[dataset.Aspartate_Aminotransferase <=2500]
dataset.shape


# # TAKING CARE OF MISSING DATA

# In[10]:


dataset.isnull().values.any()


# In[11]:


dataset.isnull().any()


# In[12]:


dataset=dataset.dropna(how='any')


# In[13]:


dataset.shape


# # Label Encoding

# In[14]:


lb=LabelEncoder()
dataset['Gender']=lb.fit_transform(dataset['Gender'])
dataset['Gender']


# In[15]:


dataset['Gender'].value_counts()


# # Splitting Dataset in to Independent variable and Dependent variable 

# In[16]:


x= dataset.iloc[:,0:10].values
x


# In[17]:


y= dataset.iloc[:,10:].values
y


# In[18]:


feat_labels = ['Age','Gender','Total_Bilirubin','Direct_Bilirubin','Alkaline_Phosphotase','Alamine_Aminotransferase','Aspartate_Aminotransferase','Total_Protiens','Albumin','Albumin_and_Globulin_Ratio']


# # Splitting The dataset in to Train set and Testing set

# In[19]:


from sklearn.model_selection import train_test_split 
x_train,x_test,y_train,y_test=train_test_split(x,y,test_size=0.2,random_state=0)


# In[20]:


print(x_train.shape, x_test.shape, y_train.shape, y_test.shape)


# # Feature scaling

# In[21]:


sc=StandardScaler()
x_train=sc.fit_transform(x_train)
x_test=sc.fit_transform(x_test)


# In[22]:


from joblib import dump
dump(sc,"scaler.save")


# In[23]:


y_test


# # Training and testing the model

# In[24]:


dt= DecisionTreeClassifier(criterion='entropy',random_state=0)


# In[25]:


dt.fit(x_train,y_train)


# In[26]:


import pickle
pickle.dump(dt,open('liver.pkl','wb'))


# In[27]:


for feature in zip(feat_labels, dt.feature_importances_):
    print(feature)


# In[28]:


y_pred=dt.predict(x_test)
print(y_pred)


# # Evaluation 

# In[29]:


r2_score(y_test,y_pred)


# In[30]:


accuracy_score(y_test,y_pred)

